# SIKA — AI Assistant untuk Ekonomi, Bisnis, dan Keuangan

Fondasi **Tahap 1** (Responsive Web App mobile-first + FastAPI Backend + Worker Queue + PostgreSQL 16 + Opaque Session Auth).

## Arsitektur Singkat
- **Frontend (`frontend/`)**: React + TypeScript + Vite + Tailwind CSS (mobile-first). Tidak menyimpan API key provider.
- **Backend API (`backend/app/main.py`)**: FastAPI + Pydantic v2 + Async SQLAlchemy. Autentikasi Argon2id + Opaque Session Cookie (`HttpOnly`, `SameSite=Lax`).
- **Worker (`backend/app/worker.py`)**: Proses terpisah yang mengambil task dari PostgreSQL menggunakan `FOR UPDATE SKIP LOCKED`.
- **Fail-Closed Config (`backend/app/core/config.py`)**: Aplikasi menolak start jika salah satu dari 12 limit wajib (TD 3.3) kosong atau `<= 0`.

## Cara Menjalankan (Local Development)

1. Salin environment template:
   ```bash
   cp .env.example .env
   ```

2. Jalankan PostgreSQL, API, dan Worker dengan Docker Compose:
   ```bash
   docker compose up --build
   ```

3. Jalankan migrasi database:
   ```bash
   docker compose exec api alembic upgrade head
   ```

4. Buat akun pengguna beta (mode invite-only):
   ```bash
   docker compose exec api python -m scripts.create_beta_user user1@sika.local PasswordKuat123!
   ```

5. Jalankan Frontend (di terminal terpisah):
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
   Buka `http://localhost:5173`.

## Menjalankan Pengujian (Unit & Security)
```bash
cd backend
pytest -v
```
