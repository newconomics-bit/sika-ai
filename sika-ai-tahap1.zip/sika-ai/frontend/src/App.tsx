import React, { useEffect, useState } from 'react';
import { api } from './lib/api';
import { AssistantTaskResponse, UsageInfo, UserMe } from './types/api';

export default function App() {
  const [user, setUser] = useState<UserMe | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [question, setQuestion] = useState('');
  const [task, setTask] = useState<AssistantTaskResponse | null>(null);
  const [usage, setUsage] = useState<UsageInfo | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.me()
      .then((u) => {
        setUser(u);
        return api.usage().then(setUsage);
      })
      .catch(() => setUser(null))
      .finally(() => setLoadingAuth(false));
  }, []);

  useEffect(() => {
    if (!task || !['queued', 'running'].includes(task.status)) return;
    const timer = setInterval(async () => {
      try {
        const updated = await api.getRequest(task.request_id);
        setTask(updated);
        if (!['queued', 'running'].includes(updated.status)) {
          api.usage().then(setUsage).catch(() => {});
        }
      } catch (err: any) {
        setErrorMsg(err.message);
      }
    }, 1500);
    return () => clearInterval(timer);
  }, [task]);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setAuthError(null);
    try {
      const u = await api.login(email, password);
      setUser(u);
      api.usage().then(setUsage).catch(() => {});
    } catch (err: any) {
      setAuthError(err.message);
    }
  }

  async function handleLogout() {
    await api.logout();
    setUser(null);
    setTask(null);
  }

  async function handleAsk(e: React.FormEvent) {
    e.preventDefault();
    if (!question.trim()) return;
    setErrorMsg(null);
    setSubmitting(true);
    try {
      const created = await api.createRequest(question.trim(), 'auto');
      setTask({ request_id: created.request_id, status: 'queued', mode: 'auto' });
      setQuestion('');
    } catch (err: any) {
      setErrorMsg(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (loadingAuth) {
    return <div className="min-h-screen flex items-center justify-center text-sm text-slate-500">Memuat SIKA...</div>;
  }

  if (!user) {
    return (
      <main className="min-h-screen flex items-center justify-center p-4">
        <form onSubmit={handleLogin} className="w-full max-w-sm bg-white rounded-xl shadow-sm border p-6 space-y-4">
          <div>
            <h1 className="text-xl font-bold text-slate-900">SIKA</h1>
            <p className="text-xs text-slate-500">Asisten Riset Ekonomi, Bisnis & Keuangan (Beta)</p>
          </div>
          {authError && <div className="text-xs bg-red-50 text-red-700 p-2.5 rounded-lg">{authError}</div>}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-700">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border px-3 py-2 text-sm"
              placeholder="nama@email.com"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-700">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border px-3 py-2 text-sm"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-slate-900 text-white rounded-lg py-2.5 text-sm font-medium hover:bg-slate-800"
          >
            Masuk
          </button>
        </form>
      </main>
    );
  }

  return (
    <div className="min-h-screen flex flex-col max-w-2xl mx-auto p-4 space-y-4">
      <header className="flex items-center justify-between border-b pb-3">
        <div>
          <h1 className="text-lg font-bold">SIKA</h1>
          <p className="text-xs text-slate-500">{user.email}</p>
        </div>
        <div className="flex items-center gap-3">
          {usage && (
            <span className="text-xs bg-slate-100 px-2.5 py-1 rounded-full text-slate-700">
              Kuota: {usage.requests_used}/{usage.requests_limit}
            </span>
          )}
          <button onClick={handleLogout} className="text-xs text-slate-600 underline">
            Keluar
          </button>
        </div>
      </header>

      <form onSubmit={handleAsk} className="space-y-2">
        <textarea
          rows={3}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Tanyakan topik ekonomi, bisnis, atau keuangan..."
          className="w-full rounded-xl border bg-white p-3 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
        />
        <button
          type="submit"
          disabled={submitting}
          className="w-full sm:w-auto bg-slate-900 text-white px-5 py-2.5 rounded-lg text-sm font-medium disabled:opacity-50"
        >
          {submitting ? 'Mengirim...' : 'Kirim Pertanyaan'}
        </button>
      </form>

      {errorMsg && <div className="text-xs bg-red-50 text-red-700 p-3 rounded-lg">{errorMsg}</div>}

      {task && (
        <section className="bg-white border rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono text-slate-500">ID: {task.request_id.slice(0, 8)}</span>
            <span className="px-2 py-0.5 rounded-full bg-slate-100 font-medium uppercase">{task.status}</span>
          </div>

          {task.result && (
            <div className="space-y-3 text-sm">
              <p className="text-slate-800 leading-relaxed">{task.result.answer.summary}</p>

              {task.result.answer.limitations.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900">
                  <div className="font-semibold mb-1">Keterbatasan</div>
                  <ul className="list-disc pl-4 space-y-1">
                    {task.result.answer.limitations.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="text-xs text-slate-500 border-t pt-2">
                Status pencarian eksternal: {task.result.research_summary.searched ? 'Dilakukan' : 'Tidak dilakukan'}
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
}
