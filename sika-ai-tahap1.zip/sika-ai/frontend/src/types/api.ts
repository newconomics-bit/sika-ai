export interface UserMe {
  id: string;
  email: string;
}

export interface UsageInfo {
  window_hours: number;
  requests_used: number;
  requests_limit: number;
}

export interface ClaimItem {
  claim_id: string;
  text: string;
  type: 'fact' | 'assumption' | 'interpretation' | 'uncertainty';
  support_status: string;
  source_ids: string[];
}

export interface AssistantResultPayload {
  schema_version: string;
  request_id: string;
  status: string;
  answer: {
    summary: string;
    limitations: string[];
    uncertainties: string[];
  };
  claims: ClaimItem[];
  sources: Array<{ id: string; title: string; final_url: string }>;
  research_summary: {
    searched: boolean;
    sources_retrieved: number;
    sources_reviewed: number;
    conflicts_found: number;
  };
}

export interface AssistantTaskResponse {
  request_id: string;
  status: 'queued' | 'running' | 'completed' | 'partial' | 'failed' | 'cancelled';
  mode: string;
  error_code?: string | null;
  result?: AssistantResultPayload | null;
}
