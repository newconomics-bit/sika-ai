import { AssistantTaskResponse, UsageInfo, UserMe } from '../types/api';

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(path, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    const msg = errBody?.detail?.message || errBody?.message || 'Terjadi kesalahan pada server.';
    throw new Error(msg);
  }
  return res.json();
}

export const api = {
  me: () => apiFetch<UserMe>('/api/v1/auth/me'),
  login: (email: string, password: string) =>
    apiFetch<UserMe>('/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  logout: () => apiFetch<{ status: string }>('/api/v1/auth/logout', { method: 'POST' }),
  usage: () => apiFetch<UsageInfo>('/api/v1/usage'),
  createRequest: (message: string, mode: 'auto' | 'research' | 'direct' = 'auto') =>
    apiFetch<{ request_id: string; status: string }>('/api/v1/assistant/requests', {
      method: 'POST',
      body: JSON.stringify({ message, mode }),
    }),
  getRequest: (requestId: string) =>
    apiFetch<AssistantTaskResponse>(`/api/v1/assistant/requests/${requestId}`),
};
