import json
import logging
import re
from datetime import datetime, timezone

SENSITIVE_PATTERN = re.compile(
    r"(bearer\s+[a-zA-Z0-9._-]+|sk-[a-zA-Z0-9_-]+|sika_session=[^;\s]+)",
    re.IGNORECASE,
)


def redact_text(value: str) -> str:
    return SENSITIVE_PATTERN.sub("[REDACTED]", value)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": redact_text(record.getMessage()),
        }
        return json.dumps(payload, ensure_ascii=False)


def configure_logging() -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(logging.INFO)
