from typing import Literal
from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_ENV: Literal["local", "test", "beta", "production"] = "local"
    DATABASE_URL: str
    ALLOWED_ORIGINS: str = "http://localhost:5173"

    # Auth & Session
    SESSION_COOKIE_NAME: str = "sika_session"
    SESSION_TTL_HOURS: int = Field(gt=0)
    SESSION_COOKIE_SECURE: bool = True
    REGISTRATION_OPEN: bool = False

    # 12 Mandatory Limit Configs (TD 3.3) - fail-closed if missing or <= 0
    REQUESTS_PER_USER_WINDOW: int = Field(gt=0)
    MODEL_CALLS_PER_TASK: int = Field(gt=0)
    INPUT_TOKEN_LIMIT: int = Field(gt=0)
    OUTPUT_TOKEN_LIMIT: int = Field(gt=0)
    RESEARCH_ITERATION_LIMIT: int = Field(gt=0)
    SEARCH_QUERY_LIMIT: int = Field(gt=0)
    RETRY_LIMIT: int = Field(gt=0)
    PROVIDER_TIMEOUT_SECONDS: int = Field(gt=0)
    SEARCH_TIMEOUT_SECONDS: int = Field(gt=0)
    MAX_REQUEST_BODY_BYTES: int = Field(gt=0)
    MAX_FETCHED_CONTENT_BYTES: int = Field(gt=0)
    MAX_REDIRECTS: int = Field(gt=0)

    # Feature Flags
    FEATURE_RESEARCH_ENABLED: bool = True
    FEATURE_BUSINESS_ANALYSIS_ENABLED: bool = False
    FEATURE_CONVERSATION_HISTORY_ENABLED: bool = False
    FEATURE_PROVIDER_FALLBACK_ENABLED: bool = False

    @property
    def allowed_origins_list(self) -> list[str]:
        return [o.strip() for o in self.ALLOWED_ORIGINS.split(",") if o.strip()]

    @model_validator(mode="after")
    def validate_security_posture(self) -> "Settings":
        if self.APP_ENV in ("beta", "production") and not self.SESSION_COOKIE_SECURE:
            raise ValueError("SESSION_COOKIE_SECURE must be True in beta/production")
        return self


settings = Settings()
