from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, verify_origin
from app.core.config import settings
from app.core.security import (
    compute_session_expiry,
    generate_session_token,
    hash_password,
    hash_session_token,
    verify_password,
)
from app.db.models import AuditEvent, Session, User
from app.db.session import get_db

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


class AuthCredentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class UserMeResponse(BaseModel):
    id: str
    email: str


@router.post("/register", status_code=status.HTTP_201_CREATED, dependencies=[Depends(verify_origin)])
async def register(payload: AuthCredentials, db: AsyncSession = Depends(get_db)):
    if not settings.REGISTRATION_OPEN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "ACCESS_DENIED", "message": "Registrasi publik ditutup (mode beta terbatas)."},
        )

    existing = await db.scalar(select(User).where(User.email == payload.email.lower()))
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"code": "VALIDATION_ERROR", "message": "Email sudah terdaftar."},
        )

    user = User(email=payload.email.lower(), password_hash=hash_password(payload.password))
    db.add(user)
    await db.commit()
    return {"id": str(user.id), "email": user.email}


@router.post("/login", dependencies=[Depends(verify_origin)])
async def login(payload: AuthCredentials, response: Response, request: Request, db: AsyncSession = Depends(get_db)):
    user = await db.scalar(select(User).where(User.email == payload.email.lower()))
    if not user or not user.is_active or not verify_password(user.password_hash, payload.password):
        db.add(
            AuditEvent(
                actor_user_id=user.id if user else None,
                action="auth.login",
                outcome="failed",
                request_id=getattr(request.state, "request_id", None),
            )
        )
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "AUTH_REQUIRED", "message": "Email atau password salah."},
        )

    raw_token = generate_session_token()
    session_obj = Session(
        user_id=user.id,
        token_hash=hash_session_token(raw_token),
        expires_at=compute_session_expiry(settings.SESSION_TTL_HOURS),
    )
    db.add(session_obj)
    db.add(
        AuditEvent(
            actor_user_id=user.id,
            action="auth.login",
            outcome="success",
            request_id=getattr(request.state, "request_id", None),
        )
    )
    await db.commit()

    response.set_cookie(
        key=settings.SESSION_COOKIE_NAME,
        value=raw_token,
        httponly=True,
        secure=settings.SESSION_COOKIE_SECURE,
        samesite="lax",
        max_age=settings.SESSION_TTL_HOURS * 3600,
        path="/",
    )
    return {"id": str(user.id), "email": user.email}


@router.post("/logout", dependencies=[Depends(verify_origin)])
async def logout(
    request: Request,
    response: Response,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    raw_token = request.cookies.get(settings.SESSION_COOKIE_NAME)
    if raw_token:
        token_hash = hash_session_token(raw_token)
        await db.execute(
            update(Session)
            .where(Session.token_hash == token_hash, Session.user_id == user.id)
            .values(revoked_at=datetime.now(timezone.utc))
        )
        db.add(
            AuditEvent(
                actor_user_id=user.id,
                action="auth.logout",
                outcome="success",
                request_id=getattr(request.state, "request_id", None),
            )
        )
        await db.commit()

    response.delete_cookie(key=settings.SESSION_COOKIE_NAME, path="/")
    return {"status": "logged_out"}


@router.get("/me", response_model=UserMeResponse)
async def me(user: User = Depends(get_current_user)):
    return UserMeResponse(id=str(user.id), email=user.email)
