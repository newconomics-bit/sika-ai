import uuid
from datetime import datetime, timedelta, timezone
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, verify_origin
from app.core.config import settings
from app.db.models import AssistantRequest, User
from app.db.session import get_db

router = APIRouter(prefix="/api/v1", tags=["assistant"])


class CreateAssistantRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    mode: Literal["auto", "research", "direct"] = "auto"
    client_request_id: str | None = Field(default=None, max_length=128)


@router.post(
    "/assistant/requests",
    status_code=status.HTTP_202_ACCEPTED,
    dependencies=[Depends(verify_origin)],
)
async def create_request(
    payload: CreateAssistantRequest,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    window_start = datetime.now(timezone.utc) - timedelta(hours=24)
    used_count = await db.scalar(
        select(func.count(AssistantRequest.id)).where(
            AssistantRequest.user_id == user.id,
            AssistantRequest.created_at >= window_start,
        )
    )
    if (used_count or 0) >= settings.REQUESTS_PER_USER_WINDOW:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "code": "QUOTA_EXCEEDED",
                "message": "Batas permintaan harian Anda telah tercapai. Silakan coba lagi besok.",
            },
        )

    req_obj = AssistantRequest(
        user_id=user.id,
        message=payload.message.strip(),
        mode=payload.mode,
        client_request_id=payload.client_request_id,
        status="queued",
    )
    db.add(req_obj)
    await db.commit()
    await db.refresh(req_obj)

    return {
        "request_id": str(req_obj.id),
        "status": req_obj.status,
        "status_url": f"/api/v1/assistant/requests/{req_obj.id}",
    }


@router.get("/assistant/requests/{request_id}")
async def get_request_status(
    request_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Strictly owner-scoped query (SEC-002 / MULTI-003)
    req_obj = await db.scalar(
        select(AssistantRequest).where(
            AssistantRequest.id == request_id,
            AssistantRequest.user_id == user.id,
        )
    )
    if not req_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"code": "ACCESS_DENIED", "message": "Permintaan tidak ditemukan."},
        )

    return {
        "request_id": str(req_obj.id),
        "status": req_obj.status,
        "mode": req_obj.mode,
        "error_code": req_obj.error_code,
        "result": req_obj.result_payload,
        "created_at": req_obj.created_at.isoformat() if req_obj.created_at else None,
        "finished_at": req_obj.finished_at.isoformat() if req_obj.finished_at else None,
    }


@router.post("/assistant/requests/{request_id}/cancel", dependencies=[Depends(verify_origin)])
async def cancel_request(
    request_id: uuid.UUID,
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    req_obj = await db.scalar(
        select(AssistantRequest).where(
            AssistantRequest.id == request_id,
            AssistantRequest.user_id == user.id,
        )
    )
    if not req_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"code": "ACCESS_DENIED", "message": "Permintaan tidak ditemukan."},
        )

    if req_obj.status in ("queued", "running"):
        req_obj.status = "cancelled"
        req_obj.finished_at = datetime.now(timezone.utc)
        await db.commit()

    return {"request_id": str(req_obj.id), "status": req_obj.status}


@router.get("/usage")
async def get_usage(
    user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    window_start = datetime.now(timezone.utc) - timedelta(hours=24)
    used_count = await db.scalar(
        select(func.count(AssistantRequest.id)).where(
            AssistantRequest.user_id == user.id,
            AssistantRequest.created_at >= window_start,
        )
    )
    return {
        "window_hours": 24,
        "requests_used": used_count or 0,
        "requests_limit": settings.REQUESTS_PER_USER_WINDOW,
    }
