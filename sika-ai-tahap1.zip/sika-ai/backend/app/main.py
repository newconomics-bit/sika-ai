import uuid
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1 import auth, requests as assistant_requests
from app.core.config import settings
from app.core.logging import configure_logging

configure_logging()

app = FastAPI(title="SIKA API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type"],
)


@app.middleware("http")
async def request_guard_middleware(request: Request, call_next):
    request.state.request_id = str(uuid.uuid4())
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > settings.MAX_REQUEST_BODY_BYTES:
        return JSONResponse(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            content={
                "code": "VALIDATION_ERROR",
                "message": "Ukuran permintaan melebihi batas maksimum.",
                "request_id": request.state.request_id,
                "retryable": False,
            },
        )
    response = await call_next(request)
    response.headers["X-Request-ID"] = request.state.request_id
    return response


@app.exception_handler(Exception)
async def safe_global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "code": "INTERNAL_ERROR",
            "message": "Terjadi kesalahan internal. Silakan coba beberapa saat lagi.",
            "request_id": getattr(request.state, "request_id", None),
            "retryable": True,
        },
    )


@app.get("/health")
async def health():
    return {"status": "ok", "env": settings.APP_ENV}


app.include_router(auth.router)
app.include_router(assistant_requests.router)
