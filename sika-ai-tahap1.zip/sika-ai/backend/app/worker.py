import asyncio
import logging
from datetime import datetime, timezone
from sqlalchemy import select

from app.core.logging import configure_logging
from app.db.models import AssistantRequest
from app.db.session import AsyncSessionLocal

configure_logging()
logger = logging.getLogger("sika.worker")


async def process_one_task() -> bool:
    async with AsyncSessionLocal() as db:
        stmt = (
            select(AssistantRequest)
            .where(AssistantRequest.status == "queued")
            .order_by(AssistantRequest.created_at.asc())
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        task = await db.scalar(stmt)
        if not task:
            return False

        task.status = "running"
        await db.commit()
        logger.info(f"Processing task_id={task.id}")

        # Tahap 1 stub: jujur menyatakan belum ada pencarian/model eksternal (FUNC-004)
        task.result_payload = {
            "schema_version": "1.0",
            "request_id": str(task.id),
            "status": "completed",
            "answer": {
                "summary": (
                    "Fondasi SIKA Tahap 1 aktif. Pertanyaan Anda telah diterima dan diproses oleh worker, "
                    "namun integrasi AI Provider Gateway (Tahap 2) dan Search Gateway (Tahap 4) belum diaktifkan."
                ),
                "sections": [],
                "limitations": [
                    "Tidak ada pencarian web atau pemanggilan model AI eksternal yang dijalankan pada Tahap 1."
                ],
                "uncertainties": [
                    "Jawaban analitis berbasis bukti baru tersedia setelah Tahap 2 dan Tahap 4 diaktifkan."
                ],
            },
            "claims": [
                {
                    "claim_id": "clm_init_1",
                    "text": "Permintaan berhasil diproses melalui antrean worker backend yang terisolasi per pengguna.",
                    "type": "fact",
                    "support_status": "supported",
                    "source_ids": [],
                }
            ],
            "sources": [],
            "research_summary": {
                "searched": False,
                "sources_retrieved": 0,
                "sources_reviewed": 0,
                "conflicts_found": 0,
            },
            "validation": {
                "schema_valid": True,
                "citation_integrity_valid": True,
                "evidence_validation_status": "passed_no_search_mode",
            },
        }
        task.status = "completed"
        task.finished_at = datetime.now(timezone.utc)
        await db.commit()
        logger.info(f"Completed task_id={task.id}")
        return True


async def main() -> None:
    logger.info("SIKA Worker started (DB-backed queue)")
    while True:
        try:
            processed = await process_one_task()
            if not processed:
                await asyncio.sleep(1.5)
        except Exception as exc:
            logger.error(f"Worker loop error: {type(exc).__name__}")
            await asyncio.sleep(3.0)


if __name__ == "__main__":
    asyncio.run(main())
