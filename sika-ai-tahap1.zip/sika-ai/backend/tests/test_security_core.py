from app.core.logging import redact_text
from app.core.security import generate_session_token, hash_password, hash_session_token, verify_password


def test_argon2_password_hashing():
    hashed = hash_password("SuperSecretPassword123!")
    assert hashed != "SuperSecretPassword123!"
    assert verify_password(hashed, "SuperSecretPassword123!") is True
    assert verify_password(hashed, "WrongPassword") is False


def test_opaque_session_token_hashing():
    token = generate_session_token()
    assert len(token) >= 48
    assert hash_session_token(token) != token


def test_log_redaction_strips_secrets():
    raw = "Error calling provider with Bearer sk-secret12345 and sika_session=abc123; ok"
    redacted = redact_text(raw)
    assert "sk-secret12345" not in redacted
    assert "abc123" not in redacted
    assert "[REDACTED]" in redacted
