import pytest
from pydantic import ValidationError
from app.core.config import Settings


def _base_env() -> dict:
    return {
        "APP_ENV": "local",
        "DATABASE_URL": "postgresql+asyncpg://u:p@localhost:5432/db",
        "SESSION_TTL_HOURS": 24,
        "SESSION_COOKIE_SECURE": False,
        "REQUESTS_PER_USER_WINDOW": 20,
        "MODEL_CALLS_PER_TASK": 6,
        "INPUT_TOKEN_LIMIT": 8000,
        "OUTPUT_TOKEN_LIMIT": 2000,
        "RESEARCH_ITERATION_LIMIT": 2,
        "SEARCH_QUERY_LIMIT": 3,
        "RETRY_LIMIT": 2,
        "PROVIDER_TIMEOUT_SECONDS": 45,
        "SEARCH_TIMEOUT_SECONDS": 15,
        "MAX_REQUEST_BODY_BYTES": 16384,
        "MAX_FETCHED_CONTENT_BYTES": 524288,
        "MAX_REDIRECTS": 3,
    }


def test_sec_009_fail_closed_on_zero_limit():
    env = _base_env()
    env["RETRY_LIMIT"] = 0
    with pytest.raises(ValidationError):
        Settings(**env)


def test_sec_009_fail_closed_beta_insecure_cookie():
    env = _base_env()
    env["APP_ENV"] = "beta"
    env["SESSION_COOKIE_SECURE"] = False
    with pytest.raises(ValidationError):
        Settings(**env)
