import asyncio
import sys
from sqlalchemy import select
from app.core.security import hash_password
from app.db.models import User
from app.db.session import AsyncSessionLocal


async def create_user(email: str, password: str) -> None:
    async with AsyncSessionLocal() as db:
        existing = await db.scalar(select(User).where(User.email == email.lower()))
        if existing:
            print(f"User {email} already exists.")
            return
        user = User(email=email.lower(), password_hash=hash_password(password))
        db.add(user)
        await db.commit()
        print(f"Created beta user: {user.email} (id={user.id})")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python -m scripts.create_beta_user <email> <password>")
        sys.exit(1)
    asyncio.run(create_user(sys.argv[1], sys.argv[2]))
